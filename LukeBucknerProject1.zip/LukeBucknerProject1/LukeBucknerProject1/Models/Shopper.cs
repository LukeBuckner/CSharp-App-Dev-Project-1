﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject1.Models
{
    /// <summary>
    /// Shopper Class
    /// </summary>
    public class Shopper
    {
        /// <summary>
        /// Gets name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; }

        /// <summary>
        /// Gets / sets the available money for a shopper.
        /// </summary>
        /// <value>
        /// The money available.
        /// </value>
        public double MoneyAvailable { get; set; }

        /// <summary>
        /// List of cars
        /// </summary>
        private readonly List<Car?> _cars;

        /// <summary>
        /// Initializes a new instance of the <see cref="Shopper"/> class.
        /// </summary>
        /// <param name="name">shopper name.</param>
        /// <param name="moneyAvailable">shopper's money available.</param>
        /// <exception cref="ArgumentException">Name cannot be null or empty.</exception>
        /// <exception cref="ArgumentOutOfRangeException">MoneyAvailable cannot be negative.</exception>
        public Shopper(string name, double moneyAvailable)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be null or empty.");
            if (moneyAvailable < 0)
                throw new ArgumentOutOfRangeException("MoneyAvailable cannot be negative.");

            Name = name;
            MoneyAvailable = moneyAvailable;
            _cars = new List<Car?>();
        }

        /// <summary>
        /// Determines whether the shopper can purchase the specified car.
        /// </summary>
        /// <param name="car">The car.</param>
        /// <returns>
        ///   <c>true</c> if this instance can purchase the specified car; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="ArgumentNullException">car</exception>
        public bool CanPurchase(Car? car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));

            double totalCost = car.Price * (1 + CarLot.TaxRate);
            return MoneyAvailable >= totalCost;
        }

        /// <summary>
        /// Purchases selected car.
        /// </summary>
        /// <param name="car">The car.</param>
        /// <exception cref="ArgumentNullException">car</exception>
        /// <exception cref="InvalidOperationException">Not enough money to purchase the car.</exception>
        public void PurchaseCar(Car? car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));

            if (CanPurchase(car))
            {
                _cars.Add(car);
                MoneyAvailable -= car.Price * (1 + CarLot.TaxRate);
            }
            else
            {
                throw new InvalidOperationException("Not enough money to purchase the car.");
            }
        }
    }
}
