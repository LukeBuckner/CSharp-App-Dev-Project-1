﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject1.Models
{
    public class Car
    {
        public string Make { get; }
        public string Model { get; }
        public double Mpg { get; }
        public double Price { get; }

        public Car(string make, string model, double mpg, double price)
        {
            if (string.IsNullOrWhiteSpace(make))
                throw new ArgumentException("Make cannot be null or empty.");
            if (string.IsNullOrWhiteSpace(model))
                throw new ArgumentException("Model cannot be null or empty.");
            if (mpg <= 0)
                throw new ArgumentOutOfRangeException("MPG must be greater than zero.");
            if (price < 0)
                throw new ArgumentOutOfRangeException("Price cannot be negative.");

            Make = make;
            Model = model;
            Mpg = mpg;
            Price = price;
        }
    }
}
