﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LukeBucknerProject1.Models
{
    /// <summary>
    /// CarLot Class
    /// </summary>
    public class CarLot
    {
        /// <summary>
        /// The inventory
        /// </summary>
        public List<Car?> Inventory;

        /// <summary>
        /// The set tax rate from instructions
        /// </summary>
        public const double TaxRate = 0.078;

        /// <summary>
        /// Initializes a new instance of the <see cref="CarLot"/> class.
        /// </summary>
        public CarLot()
        {
            Inventory = new List<Car?>();
            StockLotWithDefaultInventory();
        }

        /// <summary>
        /// Places default inventory into stock
        /// </summary>
        private void StockLotWithDefaultInventory()
        {
            Inventory.Add(new Car("Ford", "Focus ST", 28.3, 26298.98));
            Inventory.Add(new Car("Chevrolet", "Camaro ZL1", 19, 65401.23));
            Inventory.Add(new Car("Honda", "Accord Sedan EX", 30.2, 26780));
            Inventory.Add(new Car("Lexus", "ES 350", 24.1, 42101.10));
        }

        /// <summary>
        /// Finds cars by their make.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException">Make cannot be null or empty.</exception>
        public List<Car?>? FindCarsByMake(string make)
        {
            if (string.IsNullOrWhiteSpace(make))
                throw new ArgumentException("Make cannot be null or empty.");

            var result = Inventory
                .Where(car => car != null && car.Make.Equals(make, StringComparison.OrdinalIgnoreCase))
                .ToList();

            return result.Count > 0 ? result : null;
        }

        /// <summary>
        /// Finds the car by make/model.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException">Make and Model cannot be null or empty.</exception>
        public Car? FindCarByMakeModel(string make, string model)
        {
            if (string.IsNullOrWhiteSpace(make) || string.IsNullOrWhiteSpace(model))
                throw new ArgumentException("Make and Model cannot be null or empty.");

            return Inventory
                .FirstOrDefault(car => car != null &&
                                       car.Make.Equals(make, StringComparison.OrdinalIgnoreCase) &&
                                       car.Model.Equals(model, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Adds a car.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <param name="mpg">The MPG.</param>
        /// <param name="price">The price.</param>
        public void AddCar(string make, string model, double mpg, double price)
        {
            Inventory.Add(new Car(make, model, mpg, price));
        }

        /// <summary>
        /// Gets the total cost of purchase, including the tax rate on top of the listed price.
        /// </summary>
        /// <param name="car">The car.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException">car</exception>
        public double GetTotalCostOfPurchase(Car car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));
            return car.Price * (1 + TaxRate);
        }

        /// <summary>
        /// Gets the count of cars in inventory.
        /// </summary>
        /// <value>
        /// The count.
        /// </value>
        public int Count => Inventory.Count;

        /// <summary>
        /// Gets the inventory list.
        /// </summary>
        /// <value>
        /// The inventory list.
        /// </value>
        public List<Car?> InventoryList => Inventory;
    }
}
