﻿using LukeBucknerProject1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LukeBucknerProject1
{
    /// <summary>
    /// AddCarForm Form
    /// </summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class AddCarForm : Form
    {
        /// <summary>
        /// Creates a new car.
        /// </summary>
        /// <value>
        /// The new car.
        /// </value>
        public Car NewCar { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddCarForm"/> class.
        /// </summary>
        public AddCarForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of the BtnAddCar control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnAddCar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMake.Text) ||
                string.IsNullOrWhiteSpace(txtModel.Text) ||
                !double.TryParse(txtPrice.Text, out double price) ||
                !double.TryParse(txtMpg.Text, out double mpg))
            {
                MessageBox.Show(@"Please enter valid car details.");
                return;
            }

            NewCar = new Car(txtMake.Text, txtModel.Text, mpg, price);
            //close dialog box
            DialogResult = DialogResult.OK;
            Close();
        }

        /// <summary>
        /// Handles the Click event of the BtnCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //Close the box after cancel click
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
