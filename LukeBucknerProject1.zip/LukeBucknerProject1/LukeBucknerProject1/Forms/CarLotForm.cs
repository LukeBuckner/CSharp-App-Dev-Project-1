﻿using LukeBucknerProject1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LukeBucknerProject1
{
    /// <summary>
    /// CarLotForm
    /// </summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class CarLotForm : Form
    {
        /// <summary>
        /// The car lot
        /// </summary>
        private readonly CarLot _carLot;

        /// <summary>
        /// The shopper
        /// </summary>
        private Shopper _shopper;

        /// <summary>
        /// Initializes a new instance of the <see cref="CarLotForm"/> class.
        /// </summary>
        ///
        /// The resharper suggestion here does not work. It causes a ton of errors and does not initialize
        public CarLotForm()
        {
            InitializeComponent();
            _carLot = new CarLot();
            LoadCarLot();
        }

        /// <summary>
        /// Loads the lot of cars
        /// </summary>
        private void LoadCarLot()
        {
            listBoxCars.Items.Clear();
            foreach (var car in _carLot.InventoryList)
            {
                listBoxCars.Items.Add($"{car?.Make} {car?.Model} ${car?.Price:F2} {car?.Mpg}mpg");
            }
        }

        /// <summary>
        /// Handles the Click event of the BtnCreateShopper control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnCreateShopper_Click(object sender, EventArgs e)
        {
            var name = txtShopperName.Text;
            if (double.TryParse(txtMoneyAvailable.Text, out var money) && money >= 0)
            {
                _shopper = new Shopper(name, money);
                MessageBox.Show($@"Shopper created: {_shopper.Name} with ${_shopper.MoneyAvailable:F2}");
            }
            else
            {
                MessageBox.Show(@"Please enter a valid amount of money.");
            }
        }

        /// <summary>
        /// Handles the Click event of the btnPurchaseCar control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnPurchaseCar_Click(object sender, EventArgs e)
        {
            if (listBoxCars.SelectedItem != null)
            {
                var selectedCarInfo = listBoxCars.SelectedItem.ToString()?.Split(' ');
                var make = selectedCarInfo?[0];
                var model = selectedCarInfo?[1];
                // the Resharper suggestion below broke part of the functionality and would not let
                // you purchase a newly added car. Because of this, I left it how I had it. See the notes.txt file
                // for more information
                var carToPurchase = _carLot.FindCarByMakeModel(make, model);

                try
                {
                    _shopper.PurchaseCar(carToPurchase);
                    MessageBox.Show($@"Congratulations! You purchased: {make} {model}"); //resharper change
                    LoadCarLot(); // Reloads car list
                }
                catch (InvalidOperationException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(@"Select a car to purchase or create a shopper first."); //resharper change
            }
        }

        /// <summary>
        /// Handles the Click event of the AddCarToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void AddCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using var addCarForm = new AddCarForm();
            if (addCarForm.ShowDialog() != DialogResult.OK) return;
            var newCar = addCarForm.NewCar;
            _carLot.AddCar(newCar.Make, newCar.Model, newCar.Mpg, newCar.Price);
            LoadCarLot();
        }

        /// <summary>
        /// Handles the Click event of the ViewInventoryToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ViewInventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowInventory();
        }

        /// <summary>
        /// Handles the Click event of the BtnViewInventory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnViewInventory_Click(object sender, EventArgs e)
        {
            ShowInventory();
        }

        /// <summary>
        /// Shows the complete car lot inventory.
        /// </summary>
        private void ShowInventory()
        {
            var inventoryDetails = new StringBuilder();
            inventoryDetails.AppendLine($"Inventory of {_carLot.Inventory.Count} cars.");

            foreach (var car in _carLot.Inventory)
            {
                inventoryDetails.AppendLine($"{car?.Make} {car?.Model} ${car.Price:F2} {car.Mpg}mpg");
            }

            inventoryDetails.AppendLine($"\nMost expensive:\n{FindMostExpensiveCar()}");
            inventoryDetails.AppendLine($"\nLeast expensive:\n{FindLeastExpensiveCar()}");
            inventoryDetails.AppendLine($"\nBest MPG:\n{FindBestMpgCar()}");
            inventoryDetails.AppendLine($"\nWorst MPG:\n{FindWorstMpgCar()}");

            MessageBox.Show(inventoryDetails.ToString(), @"Car Inventory"); //Resharper change 
        }

        /// <summary>
        /// Finds the most expensive car.
        /// </summary>
        /// <returns></returns>
        private string FindMostExpensiveCar()
        {
            // the Resharper suggestion for car.Price below breaks the code. It works now as it is. I am not sure 
            // if that is just a mistake on Resharper so i wanted to note it here
            var mostExpensive = _carLot.Inventory.MaxBy(car => car.Price);
            return mostExpensive != null ? $"{mostExpensive.Make} {mostExpensive.Model} ${mostExpensive.Price:F2} {mostExpensive.Mpg}mpg" : "N/A";
        }

        /// <summary>
        /// Finds the least expensive car.
        /// </summary>
        /// <returns></returns>
        private string FindLeastExpensiveCar()
        {
            // Like with the FindMostExpensiveCar method above, the Resharper suggestion for car.Price below breaks the code. 
            // Left it as it is for now
            var leastExpensive = _carLot.Inventory.MinBy(car => car.Price);
            return leastExpensive != null ? $"{leastExpensive.Make} {leastExpensive.Model} ${leastExpensive.Price:F2} {leastExpensive.Mpg}mpg" : "N/A";
        }

        /// <summary>
        /// Finds the car with the best MPG.
        /// </summary>
        /// <returns></returns>
        private string FindBestMpgCar()
        {
            // Like with the methods above, the Resharper suggestion for car.Price below breaks the code. 
            // Left it as it is for now because it works how I have it
            var bestMpg = _carLot.Inventory.MaxBy(car => car.Mpg);
            return bestMpg != null ? $"{bestMpg.Make} {bestMpg.Model} ${bestMpg.Price:F2} {bestMpg.Mpg}mpg" : "N/A";
        }

        /// <summary>
        /// Finds the car with the worse MPG.
        /// </summary>
        /// <returns></returns>
        private string FindWorstMpgCar()
        {
            // Like with the methods above, the Resharper suggestion for car.Price below breaks the code. 
            // Left it as it is for now because it works how I have it
            var worstMpg = _carLot.Inventory.MinBy(car => car.Mpg);
            return worstMpg != null ? $"{worstMpg.Make} {worstMpg.Model} ${worstMpg.Price:F2} {worstMpg.Mpg}mpg" : "N/A";
        }
    }
}
