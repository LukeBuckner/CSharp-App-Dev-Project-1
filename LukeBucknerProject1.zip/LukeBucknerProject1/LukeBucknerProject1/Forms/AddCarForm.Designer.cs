﻿namespace LukeBucknerProject1
{
    partial class AddCarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMake = new TextBox();
            txtModel = new TextBox();
            txtPrice = new TextBox();
            txtMpg = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnAddCar = new Button();
            btnCancel = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // txtMake
            // 
            txtMake.Location = new Point(346, 87);
            txtMake.Name = "txtMake";
            txtMake.Size = new Size(100, 23);
            txtMake.TabIndex = 0;
            // 
            // txtModel
            // 
            txtModel.Location = new Point(346, 132);
            txtModel.Name = "txtModel";
            txtModel.Size = new Size(100, 23);
            txtModel.TabIndex = 1;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(346, 174);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(100, 23);
            txtPrice.TabIndex = 2;
            // 
            // txtMpg
            // 
            txtMpg.Location = new Point(346, 220);
            txtMpg.Name = "txtMpg";
            txtMpg.Size = new Size(100, 23);
            txtMpg.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(287, 90);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 4;
            label1.Text = "Make";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(287, 135);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 5;
            label2.Text = "Model";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(287, 174);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 6;
            label3.Text = "Price";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(287, 220);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 7;
            label4.Text = "MPG";
            // 
            // btnAddCar
            // 
            btnAddCar.Location = new Point(303, 285);
            btnAddCar.Name = "btnAddCar";
            btnAddCar.Size = new Size(75, 23);
            btnAddCar.TabIndex = 8;
            btnAddCar.Text = "Add Car";
            btnAddCar.UseVisualStyleBackColor = true;
            btnAddCar.Click += BtnAddCar_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(408, 285);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 9;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += BtnCancel_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(287, 25);
            label5.Name = "label5";
            label5.Size = new Size(186, 15);
            label5.TabIndex = 10;
            label5.Text = "Please Enter the Following Details:";
            // 
            // AddCarForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(btnCancel);
            Controls.Add(btnAddCar);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtMpg);
            Controls.Add(txtPrice);
            Controls.Add(txtModel);
            Controls.Add(txtMake);
            Name = "AddCarForm";
            Text = "AddCarForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMake;
        private TextBox txtModel;
        private TextBox txtPrice;
        private TextBox txtMpg;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnAddCar;
        private Button btnCancel;
        private Label label5;
    }
}