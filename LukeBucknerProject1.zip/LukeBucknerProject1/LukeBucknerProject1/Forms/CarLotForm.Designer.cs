﻿namespace LukeBucknerProject1
{
    partial class CarLotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxCars = new ListBox();
            txtShopperName = new TextBox();
            txtMoneyAvailable = new TextBox();
            btnCreateShopper = new Button();
            btnPurchaseCar = new Button();
            menuStrip1 = new MenuStrip();
            menuToolStripMenuItem = new ToolStripMenuItem();
            addCarToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            showInventoryToolStripMenuItem = new ToolStripMenuItem();
            BtnViewInventory = new Button();
            menuToolStripMenuItem1 = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // listBoxCars
            // 
            listBoxCars.FormattingEnabled = true;
            listBoxCars.ItemHeight = 15;
            listBoxCars.Location = new Point(12, 40);
            listBoxCars.Name = "listBoxCars";
            listBoxCars.Size = new Size(402, 334);
            listBoxCars.TabIndex = 0;
            // 
            // txtShopperName
            // 
            txtShopperName.Location = new Point(599, 99);
            txtShopperName.Name = "txtShopperName";
            txtShopperName.Size = new Size(100, 23);
            txtShopperName.TabIndex = 1;
            // 
            // txtMoneyAvailable
            // 
            txtMoneyAvailable.Location = new Point(599, 142);
            txtMoneyAvailable.Name = "txtMoneyAvailable";
            txtMoneyAvailable.Size = new Size(100, 23);
            txtMoneyAvailable.TabIndex = 2;
            // 
            // btnCreateShopper
            // 
            btnCreateShopper.Location = new Point(599, 182);
            btnCreateShopper.Name = "btnCreateShopper";
            btnCreateShopper.Size = new Size(100, 23);
            btnCreateShopper.TabIndex = 3;
            btnCreateShopper.Text = "Create Shopper";
            btnCreateShopper.UseVisualStyleBackColor = true;
            btnCreateShopper.Click += BtnCreateShopper_Click;
            // 
            // btnPurchaseCar
            // 
            btnPurchaseCar.Location = new Point(599, 246);
            btnPurchaseCar.Name = "btnPurchaseCar";
            btnPurchaseCar.Size = new Size(100, 23);
            btnPurchaseCar.TabIndex = 4;
            btnPurchaseCar.Text = "Purchase Car";
            btnPurchaseCar.UseVisualStyleBackColor = true;
            btnPurchaseCar.Click += BtnPurchaseCar_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 6;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            menuToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addCarToolStripMenuItem, showInventoryToolStripMenuItem, menuToolStripMenuItem1 });
            menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            menuToolStripMenuItem.ShortcutKeyDisplayString = "";
            menuToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.F;
            menuToolStripMenuItem.Size = new Size(50, 20);
            menuToolStripMenuItem.Text = "Menu";
            // 
            // addCarToolStripMenuItem
            // 
            addCarToolStripMenuItem.Name = "addCarToolStripMenuItem";
            addCarToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.A;
            addCarToolStripMenuItem.Size = new Size(185, 22);
            addCarToolStripMenuItem.Text = "Add Car";
            addCarToolStripMenuItem.Click += AddCarToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(471, 40);
            label1.Name = "label1";
            label1.Size = new Size(307, 15);
            label1.TabIndex = 7;
            label1.Text = "Enter the Following Information to create a new shopper:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(489, 99);
            label2.Name = "label2";
            label2.Size = new Size(94, 15);
            label2.TabIndex = 8;
            label2.Text = "Shopper's Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(433, 145);
            label3.Name = "label3";
            label3.Size = new Size(150, 15);
            label3.TabIndex = 9;
            label3.Text = "Shopper's Available Money";
            // 
            // showInventoryToolStripMenuItem
            // 
            showInventoryToolStripMenuItem.Name = "showInventoryToolStripMenuItem";
            showInventoryToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.I;
            showInventoryToolStripMenuItem.Size = new Size(185, 22);
            showInventoryToolStripMenuItem.Text = "View Inventory";
            showInventoryToolStripMenuItem.Click += ViewInventoryToolStripMenuItem_Click;
            // 
            // BtnViewInventory
            // 
            BtnViewInventory.Location = new Point(153, 398);
            BtnViewInventory.Name = "BtnViewInventory";
            BtnViewInventory.Size = new Size(100, 23);
            BtnViewInventory.TabIndex = 10;
            BtnViewInventory.Text = "View Inventory";
            BtnViewInventory.UseVisualStyleBackColor = true;
            BtnViewInventory.Click += BtnViewInventory_Click;
            // 
            // menuToolStripMenuItem1
            // 
            menuToolStripMenuItem1.Name = "menuToolStripMenuItem1";
            menuToolStripMenuItem1.Size = new Size(185, 22);
            menuToolStripMenuItem1.Text = "Menu";
            // 
            // CarLotForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnViewInventory);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnPurchaseCar);
            Controls.Add(btnCreateShopper);
            Controls.Add(txtMoneyAvailable);
            Controls.Add(txtShopperName);
            Controls.Add(listBoxCars);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "CarLotForm";
            Text = "CarLotForm";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxCars;
        private TextBox txtShopperName;
        private TextBox txtMoneyAvailable;
        private Button btnCreateShopper;
        private Button btnPurchaseCar;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuToolStripMenuItem;
        private ToolStripMenuItem addCarToolStripMenuItem;
        private Label label1;
        private Label label2;
        private Label label3;
        private ToolStripMenuItem showInventoryToolStripMenuItem;
        private Button BtnViewInventory;
        private ToolStripMenuItem menuToolStripMenuItem1;
    }
}